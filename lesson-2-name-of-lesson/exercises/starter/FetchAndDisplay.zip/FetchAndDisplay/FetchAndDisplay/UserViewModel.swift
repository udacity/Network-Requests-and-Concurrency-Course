//
//  UserViewModel.swift
//  //  FetchAndDisplay

//
//  Created by V Scarlata on 5/3/24.
//
import Foundation

/// ViewModel for fetching and storing user data from an API.
@Observable class UserViewModel {
    var users: [User]? = nil  // Holds the fetched users.

    /// Fetches user data from the API and decodes it into User models.
    func fetchData() {
        guard let url = URL(string: "https://randomuser.me/api/") else {
            print("Invalid URL")
            return
        }

        // TODO: Implement the URLSession data task to fetch user data.
        // Use JSONDecoder to decode the fetched JSON into UserResponse.
        // Update 'users' with the fetched users on successful decoding.
        // Print any errors encountered during fetching or decoding.
    }
}
