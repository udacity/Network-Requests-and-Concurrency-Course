//
//  User.swift
//  FetchAndDisplay

//
//  Created by Ferhat Abdullahoglu on 7.05.2024.
//
import Foundation

/// Represents the location details of a user.
struct Location: Codable {
    var city: String
    var state: String
    var country: String
}

/// Represents the date of birth details.
struct DateOfBirth: Codable {
    var date: String
}

/// Represents the picture URLs of a user.
struct Picture: Codable {
    var thumbnail: URL
    var medium: URL
    var large: URL
}

/// Represents user name fields
struct Name: Codable {
    let title: String
    let first: String
    let last: String
}

/// Represents a user, decoding from JSON.
struct User: Codable, Identifiable {
    var id: String { UUID().uuidString } // Provides a unique identifier for each user.
    
    // TODO: Declare properties for name, email, dateOfBirth, picture, and location.
    // Use appropriate data types and make sure they conform to Codable.
    
    // TODO: Implement computed property 'fullname' that combines first and last name.
    
    // TODO: Implement CodingKeys enum to map JSON keys to Swift property names.
    // Hint: Map 'dob' in JSON to 'dateOfBirth' in Swift.
}
