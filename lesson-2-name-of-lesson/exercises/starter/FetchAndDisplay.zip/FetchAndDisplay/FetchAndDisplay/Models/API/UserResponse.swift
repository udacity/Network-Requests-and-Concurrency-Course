//
//  UserResponse.swift
//  FetchAndDisplay
//
//  Created by Ferhat Abdullahoglu on 7.05.2024.
//

import Foundation
/// Represents the JSON structure returned from the Random User API.
/// This struct is crucial for decoding as it directly maps to the top-level "results" key in the JSON response.
struct UserResponse: Codable {
    var results: [User]  // An array of User objects as provided by the API.
}
