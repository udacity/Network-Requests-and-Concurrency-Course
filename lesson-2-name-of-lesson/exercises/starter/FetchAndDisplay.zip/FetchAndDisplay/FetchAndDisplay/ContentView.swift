//
//  ContentView.swift
//  FetchAndDisplay
//
//  Created by V Scarlata on 5/3/24.
//
import SwiftUI
import SwiftUI

/// A view that displays user details fetched from an API.
struct ContentView: View {
    @State var viewModel = UserViewModel()  // ViewModel to manage the data.

    var body: some View {
        ScrollView {
            VStack {
                // TODO: Check if users are available and display them.
                // Use a conditional statement to check for nil and iterate with ForEach if not.
                // For each user, display their details in a UserCard.
                // Display a fetching message while users are nil.
            }
        }
        .onAppear {
            viewModel.fetchData()  // Fetch user data when the view appears.
        }
    }
}

/// A view that represents a card for displaying user details.
struct UserCard: View {
    var user: User  // The user to display.

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // TODO: Add an AsyncImage to load and display the user's large picture.
            // Display the user's full name, email, and location in Text views.
            // Style the Text views to differentiate between the types of information.
        }
        .padding()
    }
}

// Preview provider for SwiftUI previews in Xcode.
#Preview {
    ContentView()
}
