//
//  User.swift
//  FetchAndDisplay

//
//  Created by Ferhat Abdullahoglu on 7.05.2024.
//
import Foundation

/// Represents the location details of a user.
struct Location: Codable {
    var city: String
    var state: String
    var country: String
}

struct DateOfBirth: Codable {
    var date: String
}

/// Represents the picture URLs of a user.
struct Picture: Codable {
    var thumbnail: URL
    var medium: URL
    var large: URL 
}

/// Represents user name fields
struct Name: Codable {
    let title: String
    let first: String
    let last: String
}

/// Represents a user, decoding from JSON. Utilizes Swift's Codable for automatic decoding.
struct User: Codable, Identifiable {
    private(set) var name: Name
    private(set) var email: String
    private(set) var dateOfBirth: DateOfBirth
    private(set) var picture: Picture
    private(set) var location: Location
    var id: String { UUID().uuidString }
    var fullname: String {
        name.first + " " + name.last
    }
    

    // Custom keys are specified only where necessary to map JSON structure directly to Swift properties.
    enum CodingKeys: String, CodingKey {
        case name, email, location, picture
        case dateOfBirth = "dob" // Maps 'dob' in JSON to 'dateOfBirth' in the Swift model.
    }
}
