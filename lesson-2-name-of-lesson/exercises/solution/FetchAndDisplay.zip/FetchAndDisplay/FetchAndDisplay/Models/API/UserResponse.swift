//
//  UserResponse.swift
//  FetchAndDisplay
//
//  Created by Ferhat Abdullahoglu on 7.05.2024.
//

import Foundation
/// Users response container
struct UserResponse: Codable {
    var results: [User]
}
