//
//  ContentView.swift
//  FetchAndDisplay

//
//  Created by V Scarlata on 5/3/24.
//
import SwiftUI

/// A view that displays user details fetched from an API.
struct ContentView: View {
    @State var viewModel = UserViewModel()  // Using @State to maintain the view model.

    var body: some View {
        ScrollView {
            VStack {
                if let users = viewModel.users {
                    ForEach(users) { user in // Using email as a unique identifier
                        UserCard(user: user)
                            .padding()
                            .background(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .shadow(radius: 5)
                            .padding([.horizontal, .top])
                    }
                } else {
                    Text("Fetching user data...")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .padding()
                }
            }
        }
        .task {
            await viewModel.fetchData() // Fetch user data when the view appears.
        }
    }
}

/// A view that represents a card for displaying user details.
struct UserCard: View {
    var user: User

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // User image
            AsyncImage(url: user.picture.large) { image in
                image
                    .resizable()
                    .frame(width: 150, height: 150)
                    .overlay(Circle().stroke(Color.gray.opacity(0.2), lineWidth: 1)) // Adding a border
            } placeholder: {
                ProgressView()
            }
            .frame(width: 150, height: 150)
            .clipShape(Circle())

            // User name
            Text("Name: \(user.fullname)")
                .font(.title2)
                .fontWeight(.bold)

            // User email
            Text("Email: \(user.email)")
                .font(.subheadline)
                .foregroundColor(.secondary)

            // User location
            Text("Location: \(user.location.city), \(user.location.state), \(user.location.country)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
    }
}

// Preview provider for SwiftUI previews in Xcode.
#Preview {
    ContentView()
}
