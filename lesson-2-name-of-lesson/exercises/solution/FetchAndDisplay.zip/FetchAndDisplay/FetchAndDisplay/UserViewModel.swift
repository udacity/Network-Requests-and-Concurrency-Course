//
//  UserViewModel.swift
//  //  FetchAndDisplay

//
//  Created by V Scarlata on 5/3/24.
//

import Foundation

@Observable final class UserViewModel {
    var users: [User]? = nil

    func fetchData() async {
        guard let url = URL(string: "https://randomuser.me/api/") else {
            print("Invalid URL")
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let usersResponse = try JSONDecoder().decode(UserResponse.self, from: data)
            await MainActor.run {
                users = usersResponse.results
            }
        } catch {
            print("Error fetching data: \(error)")
        }
    }
}
