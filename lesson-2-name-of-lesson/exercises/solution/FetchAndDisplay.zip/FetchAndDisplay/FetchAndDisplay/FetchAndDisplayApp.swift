//
//  FetchAndDisplayApp.swift
//  FetchAndDisplayApp
//
//  Created by V Scarlata on 5/3/24.
//

import SwiftUI

@main
struct FetchAndDisplayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
