//
//  DataFetcherApp.swift
//  DataFetcher
//
//  Created by V Scarlata on 5/3/24.
//

import SwiftUI

@main
struct DataFetcherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
