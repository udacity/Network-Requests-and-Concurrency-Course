//
//  UserViewModel.swift
//  DataFetcher
//
//  Created by V Scarlata on 5/3/24.
//
import Foundation
import Combine

class UserViewModel: ObservableObject {
    @Published var name: String = ""
    @Published var email: String = ""

    // Fetching logic will go here
    func fetchData() {
        // Create a URL object
        guard let url = URL(string: "https://randomuser.me/api/") else {
            print("Invalid URL")
            return
        }

        // Create a data task
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            // Code to handle response will go here
        }

        // Start the data task
        task.resume()
    }
}


