//
//  ContentView.swift
//  DataFetcher
//
//  Created by V Scarlata on 5/3/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Name:")
                .font(.title)
                .padding()
            Text("Email:")
                .font(.title)
                .padding()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
